import streamlit as st
from PIL import Image

def main():
    st.markdown("""
        <style>
            body {
                font-family: 'Arial', sans-serif;
                background-color: #f5f5f5;
            }
            .title {
                font-size: 3em;
                font-weight: bold;
                color: #4CAF50;
                text-align: center;
                margin-top: 20px;
            }
            .description {
                text-align: center;
                font-size: 1.2em;
                margin-bottom: 30px;
            }
            .container {
                display: flex;
                flex-direction: column;
                align-items: center;
                margin-top: 50px;
            }
            .card {
                background-color: white;
                border-radius: 10px;
                box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
                transition: 0.3s;
                width: 80%;
                max-width: 400px;
                text-align: center;
                margin-bottom: 30px;
            }
            .card:hover {
                box-shadow: 0 8px 16px 0 rgba(0, 0, 0, 0.2);
            }
            .button {
                background-color: #4CAF50;
                border: none;
                color: white;
                padding: 10px 20px;
                text-align: center;
                text-decoration: none;
                display: inline-block;
                font-size: 16px;
                margin-top: 10px;
                cursor: pointer;
                border-radius: 5px;
                transition: background-color 0.3s ease;
            }
            .button:hover {
                background-color: #45a049;
            }
            .card img {
                border-radius: 10px;
                max-height: 200px;
                width: auto;
            }
        </style>
    """, unsafe_allow_html=True)

    st.markdown('<h1 class="title">Gesture Learn</h1>', unsafe_allow_html=True)
    st.markdown('<p class="description">Welcome to Gesture Learn! This platform offers two main features: a Math Solver and a Sign Language Detection app.</p>', unsafe_allow_html=True)

    st.markdown('<div class="container">', unsafe_allow_html=True)

    # Math Solver Section
    st.markdown('<div class="card">', unsafe_allow_html=True)
    st.image(Image.open("images/Mathsolver.jpg"), use_column_width=True)
    if st.button("Go to Math Solver", key="math_solver_button"):
        st.session_state.page = "math_solver"
    st.markdown('</div>', unsafe_allow_html=True)
    
    # Sign Language Detection Section
    st.markdown('<div class="card">', unsafe_allow_html=True)
    st.image(Image.open("images/signlang.jpg"), use_column_width=True)
    if st.button("Go to Sign Language Detection", key="sign_language_button"):
        st.session_state.page = "sign_language_detection"
    st.markdown('</div>', unsafe_allow_html=True)

    st.markdown('</div>', unsafe_allow_html=True)

# Initialize session state
if "page" not in st.session_state:
    st.session_state.page = "main"

# Page navigation
if st.session_state.page == "main":
    main()
elif st.session_state.page == "math_solver":
    import main  # Import the math solver script
    main.run_math_solver()  # Call the function to run the math solver page
elif st.session_state.page == "sign_language_detection":
    import Sign_language_detetion
    Sign_language_detetion.app()  # Ensure sign_language_detection.py has an `app()` function
